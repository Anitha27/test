import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { DynamicFilterComponent } from './dynamic-filter.component';

import * as TTConfig from '../components/dynamic-filter/static-data/TT-screens-config.json';
import * as STConfig from '../components/dynamic-filter/static-data/ST-screens-config.json';

describe('DynamicFilterComponent', () => {
  let component: DynamicFilterComponent;
  let fixture: ComponentFixture<DynamicFilterComponent>;

  beforeEach(async(() => {
    TestBed.resetTestEnvironment();
    TestBed.initTestEnvironment(BrowserDynamicTestingModule,
       platformBrowserDynamicTesting());

    TestBed.configureTestingModule({
      declarations: [ DynamicFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicFilterComponent);
    component = fixture.componentInstance;
    console.log(JSON.parse(JSON.stringify(component)));
    fixture.detectChanges();
  });

  it('should show the currency on selecting the country name', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
