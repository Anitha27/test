import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { MaterialModule } from '../material.module';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { DynamicFilterComponent } from './dynamic-filter/dynamic-filter.component';
import { ListComponent } from './list/list.component';
import { DynFormModule } from './dyn-forms/dyn-forms.module';
import { LoadingIndicatorComponent } from './loading-indicator/loading-indicator-component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    FormsModule,
    DynFormModule
  ],
  declarations: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    DynamicFilterComponent,
    ListComponent,
    LoadingIndicatorComponent
  ],
  exports: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    DynamicFilterComponent,
    ListComponent,
    LoadingIndicatorComponent
  ]
})
export class ComponentsModule { }
