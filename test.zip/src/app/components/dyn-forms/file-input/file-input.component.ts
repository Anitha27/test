import { Component, OnInit, EventEmitter, Output, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FieldConfig } from '../field.interface';
import { OttUtility } from 'app/common/OttUtility';
@Component({
    selector: 'app-dynamic-file-input',
    template: `<div [formGroup]="group">
    <input type="file" #file [formControlName]="field.name" (change)="onFileChange($event)"
    [placeholder]="field.label" [type]="field.inputType"><br />
    <ng-container *ngFor="let validation of field.validations;" ngProjectAs="mat-error">
<mat-error *ngIf="group.get(field.name).hasError(validation.name)">{{validation.message}}</mat-error>
</ng-container>
    </div>`,
    styles: []
})
export class FileInputComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    files: any;
    @ViewChild('file') fileInput;

    constructor(private cd: ChangeDetectorRef) { }
    ngOnInit() { }

    onFileChange(event) {
        const reader = new FileReader();
        if (event.target.files && event.target.files.length) {
            const [file] = event.target.files;
            OttUtility.files = (this.fileInput && this.fileInput.nativeElement) ? this.fileInput.nativeElement.files : [];
            reader.readAsDataURL(file);
            const obj = {};
            reader.onload = () => {
                obj[this.field.name] = reader.result;
                if (!this.group.contains(this.field.name + '_file_content')) {
                    this.group.addControl(this.field.name + '_file_content', new FormControl());
                }
                this.group.controls[this.field.name + '_file_content'].setValue(reader.result);
                // this.group.patchValue(obj);

                // need to run CD since file load runs outside of zone
                this.cd.markForCheck();
            };
        }
    }
}
