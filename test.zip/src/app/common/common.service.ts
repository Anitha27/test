import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpParams } from '@angular/common/http';
import { Request, Response } from 'express';
import { Observable, Subject, BehaviorSubject } from 'rxjs/Rx';
import { OttUtility } from './OttUtility';
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
declare var $: any;

@Injectable()
export class CommonService {
  headers: any;
  searchTermSearched = new Subject();

  private _filteredResults = new BehaviorSubject<any>(null);

  constructor(private http: HttpClient) {
    this.headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  }

  updateFilteredResults(resultsSet) {
    this._filteredResults.next(resultsSet)
  }

  getFilteredResults(): Observable<any> {
    return this._filteredResults.asObservable();
  }

  getHttpPostMultiPartResponse(formData, url): Observable<any[]> {
    const body = formData;
    return this.http
      .post(url, body, { observe: 'response' })
      .map((res: Response) => {
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        return Observable.throw(new Error(error.status));
      });
  }

  getHttpPostResponse(request, url): Observable<any[]> {
    const body = request;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http
      .post(url, body, { headers, observe: 'response' })
      .map((res: Response) => {
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        return Observable.throw(new Error(error.status));
      });
  }

  getHttpPutResponse(request, url): Observable<any[]> {
    const body = request;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http
      .put(url, body, { headers, observe: 'response' })
      .map((res: Response) => {
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        return Observable.throw(new Error(error.status));
      });
  }

  getHttpGetResponse(url): Observable<any[]> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http
      .get(url, { observe: 'response' })
      .map((res: Response) => {
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        return Observable.throw(new Error(error.status));
      });
  }

  getHttpLoginResponse(url): Observable<any[]> {
    return this.http
      .get(url, { observe: 'response' })
      .map((res: Response) => {
        if (res.status === 302) {
          OttUtility.clearAllSessionStorageItems();
          window.location.href = OttUtility.urlParams.wssoLogoutUrl.url;
          return;
        }
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        OttUtility.clearAllSessionStorageItems();
        window.location.href = OttUtility.urlParams.wssoLogoutUrl.url;
        return Observable.throw(new Error(error.status));
      });
  }

  logoutOTT() {
    window.location.href = OttUtility.urlParams.wssoLogoutUrl.url;
    OttUtility.clearAllSessionStorageItems();
  }

  getAPIResponse(url, request = null, type): Observable<any[]> {
    if (!url) {
      return null;
    }
    if (type === 'GET') {
      return this.getHttpGetResponse(url);
    } else if (type === 'POST') {
      return this.getHttpPostResponse(request, url);
    } else if (type === 'PUT') {
      return this.getHttpPutResponse(request, url);
    } else if (type === 'MultiPart') {
      const formData = request;
      return this.getHttpPostMultiPartResponse(formData, url);
    } else {
      return null;
    }
  }

  getGenericForkJoin(requestArr) {
    const responseArr = [];
    requestArr.map((request) => {
      responseArr.push(this.getAPIResponse(request.url, request.param, request.type));
    });
    return forkJoin(responseArr);
  }

  formatDateTime(date: Date = new Date(), format: string = 'dd-mm-yyyy') {
    return moment(date).format(format);
  }

  showNotifier(message, type) {
    let color = '';
    if (type === 'error') {
      color = 'danger';
    } else if (type === 'warning') {
      color = 'warning';
    } else if (type === 'info') {
      color = 'info';
    } else if (type === 'success') {
      color = 'success';
    }

    $.notify({
      icon: 'notifications',
      message: message

    }, {
        type: color,
        timer: 3000,
        placement: {
          from: 'top',
          align: 'right'
        },
        template: '<div data-notify="container" class="col-xl-4 col-lg-4' +
          'col-11 col-sm-4 col-md-4 alert alert-{0} alert-with-icon" role="alert">' +
          '<button mat-button  type="button" aria-hidden="true" class="close ' +
          'mat-button" data-notify="dismiss">  <i class="material-icons">close</i></button>' +
          '<i class="material-icons" data-notify="icon">notifications</i> ' +
          '<span data-notify="title">{1}</span> ' +
          '<span data-notify="message">{2}</span>' +
          '<div class="progress" data-notify="progressbar">' +
          '<div class="progress-bar progress-bar-{0}" role="progressbar"' +
          'aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
          '</div>' +
          '<a href="{3}" target="{4}" data-notify="url"></a>' +
          '</div>'
      });
  }
}
