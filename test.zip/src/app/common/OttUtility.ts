import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
// tslint:disable-next-line:import-blacklist
import { Observable } from 'rxjs/Rx';
import * as moment from 'moment';
import { environment } from '../../environments/environment';
@Injectable()
export class OttUtility {

    static isLocal = !environment.production;
    static userDetails: any = {};
    static loggedInCountryDetails: any = {};
    static redirection: any;
    static commonStaticObject: any = {};
    static fullOriginPath = window.location.origin;
    static roleActions: any = {};
    static files: FileList;
    static localUrl = 'https://ca-uat-cluster.emea.fedex.com:8443/dev/ftt';
    static user = (OttUtility.isLocal) ? '125335' : '';
    static urlParams = {
        userServiceBaseUrl: {
            url:
                (OttUtility.isLocal) ? `${OttUtility.localUrl}/user/v1` : OttUtility.getContextPath(),
            type: 'GET'
        },
        businessServiceBaseUrl: {
            url:
                (OttUtility.isLocal) ? `${OttUtility.localUrl}/v1` : (`${OttUtility.getContextPath()}/v1`),
            type: 'GET'
        },
        adminServiceBaseUrl: {
            url:
                (OttUtility.isLocal) ? `${OttUtility.localUrl}/admin/v1` :
                    (`${OttUtility.getContextPath()}/admin/v1`),
            type: 'GET'
        },
        uiBaseUrl: {
            url: (OttUtility.isLocal) ? 'localUrl/user/v1' : OttUtility.getContextPath()
        },
        wssoLoginHdr: { url: `/loggedinuser/${OttUtility.user}`, type: 'GET' },
        escSrvc: { url: `/loggedinuser/${OttUtility.user}`, type: 'GET' },
        wssoLogoutUrl: { url: '/logout', type: 'GET' },
        genericInfoUrl: { url: '/country/info/', type: 'GET' },
        genericTarrifTypes: { url: '/country/tariff/selection/criteria', type: 'POST' },
        genericServiceTypes: { url: '/country/products', type: 'POST' },
        getDiscounts: { url: '/data/countryLevelDiscounts', type: 'POST' },
        getZone: { url: '/service/zones/info', type: 'POST' },
        getSurcharges: { url: '/surcharges/info', type: 'POST' },
        createSalesFeed: { url: '/salesfeed', type: 'POST' },
        getTariffHistory: { url: '/activity/view/list', type: 'GET' },
        getLoadingTariffHistory: { url: '/loading/view/list', type: 'GET' },
        updateTariff: { url: '/tariff/update/', type: 'POST' },
        generatePDF: { url: '/reports/tariff', type: 'GET' },
        sneakPreview: { url: '/sneak/preview', type: 'POST' },
        getWeightbrkdwn: { url: '/weight/breakage/', type: 'GET' },
        generateExcel: { url: '/reports/excel', type: 'GET' },
        getSaleFeedInfo: { url: '/salesfeed/', type: 'GET' },
        generateLI: { url: '/reports/excel/loading-instructions', type: 'GET' },
        generateLIDom: { url: '/reports/excel/loading-instructions-domestic', type: 'GET' },
        updateSalesFeed: { url: '/salesfeed/', type: 'PUT' },
        getCountryLane: { url: '/country/details', type: 'POST' },
        getStandardDiscounts: { url: '/standard/tariff', type: 'POST' },
        genStdTariff: { url: '/reports/standard/tariff', type: 'GET' },
        uploadPt: { url: '/personalised/tariff/upload', type: 'POST' },
        downloadPT: { url: '/personalised/tariff/download/', type: 'GET' },
        getStatuses: { url: '/tariff/get/all/status', type: 'GET' },
        getPTSaleFeedInfo: { url: '/approval/personalized/status', type: 'POST' },
        postPTApproval: { url: '/approval/personalized/selection', type: 'POST' },
        getTariffInfo: { url: '/approval/personalized/info/status/', type: 'POST' },
        confrmST: { url: '/salesfeed/confirm/standard/tariff', type: 'POST' },
        updatePTOpco: { url: '/personalised/tariff/update/opco', type: 'PUT' },
        postPersnlDetl: { url: '/personalised/tariff/details', type: 'POST' },
        partlyAwardedSave: { url: '/partly/awarded/save', type: 'PUT' },
        getPartlyAwarded: { url: '/partly/awarded/get', type: 'GET' },
        countrySplitURL: { url: '/data/countrySplit', type: 'POST' },
        zoningTTURL: { url: '/data/zonningAndTT', type: 'POST' },
        getAdminCountryList: { url: '/countries/tariff/threshold', type: 'GET' },
        postAdminDetl: { url: '/data/countrySTSettings', type: 'POST' },
        getStandardDetl: { url: '/standard/tariffs', type: 'GET' },
        getPersonalisedDetl: { url: '/personalized/tariffs', type: 'GET' },
        postThreshold: { url: '/save/threshold', type: 'POST' },
        fetchPTOnGO: { url: '/personalized/tariff/get', type: 'POST' },
        fetchSTOnGO: { url: '/standard/tariff/get', type: 'POST' },
        saveST: { url: '/standard/tariff', type: 'MultiPart' },
        savePT: { url: '/personalized/tariff', type: 'POST' },
        uploadFTT: { url: '/excel/uploadFile', type: 'POST' },
        listPrice: { url: '/countries/list/price', type: 'GET' },
        fetchAvlbDate: { url: '/fetch/li/dates', type: 'POST' },
        fetchLstPric: { url: '/fetch/list/price', type: 'POST' },
        activityVwPgs: { url: '/activity/view/pages', type: 'POST' },
        removeSTURL: { url: '/standard/tariff/remove', type: 'POST' },
        adminCountryServices: { url: '/service/details', type: 'POST' },
        adminCountryDetails: { url: '/country/list', type: 'GET' },
        ZoningTTHeaders: { url: '/data/zonningAndTTHeader', type: 'POST' },
        CountrySplitHeaders: { url: '/data/countrySplitHeader', type: 'POST' },
        getCountryOP: { url: '/data/countryOpUnitDetails', type: 'POST' },
        CountryDetails: { url: '/data/country', type: 'POST' },
        CountryTTSAvlDts: { url: '/data/countryTariffTypeSettingsAvailableDates', type: 'POST' },
        TTSClosestDate: { url: '/data/closestCountryTariffTypeRevInfo', type: 'POST' },
        getTariffTypes: { url: '/data/countryTariffTypeSettings', type: 'POST' },
        saveTariffTypes: { url: '/save/tariffTypeSetting', type: 'POST' },
        stSettingsAvailableDates: { url: '/data/stSettingsAvailableDates', type: 'POST' },
        closestStandardTariffDiscInfo: { url: '/data/closestStandardTariffDiscInfo', type: 'POST' },
        countrySTSettings: { url: '/data/countrySTSettings', type: 'POST' },
        deleteSTRow: { url: '/standard/tariff/remove', type: 'POST' },
        deleteThreshold: { url: '/remove/threshold', type: 'POST'},
        getBandDownloadTrf: { url: '/reports/band/files', type: 'GET'},
        notificationSettingsAvailableDates: { url: '/data/notificationSettingsAvailableDates', type: 'POST' },
        closestNotificationInfo: { url: '/data/closestNotificationInfo', type: 'POST' },
        notificationSettings: { url: '/data/notificationSettings', type: 'POST' },
        getEmailTemplateById: { url: '/data/getEmailTemplateById', type: 'POST' }
    }

    static getContextPath() {
        return window.location.pathname.substring(0, window.location.pathname.indexOf('/', 2));
    }

    static formatDateTime(date: Date = new Date(), format: string = 'dd-mm-yyyy') {
        return moment(date).format(format);
    }

    static toHttpParams(obj: object): HttpParams {
        // convert class/json/object to HttpParams
        let params = new HttpParams();
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                const val = obj[key];
                if (val !== null && val !== undefined) {
                    params = params.append(key, val.toString());
                }
            }
        }
        return params;
    }

    static seSessionStorageItem(itemName: string, item: string): void {
        sessionStorage.setItem(itemName, item);
    }

    static getSessionStorageItem(itemName: string): string {
        return sessionStorage.getItem(itemName);
    }

    static clearAllSessionStorageItems() {
        return sessionStorage.clear();
    }

    static errorHandler(error): Observable<string> {
        if (error.status === 500) {
            return Observable.throw(new Error('Error while processing request'));
        } else if (error.status === 400 || error.status === 401) {
            return Observable.throw(new Error('Invalid username and password'));
        } else if (error.status === 409) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 406) {
            return Observable.throw(new Error(error.status));
        }
    }
}
