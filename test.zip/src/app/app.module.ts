import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { PendingInterceptorModule} from './components/loading-indicator/pending-interceptor.module';
import { UserIdleModule } from 'angular-user-idle';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { NgxBootstrapProductTourModule , NgxBootstrapProductTourService} from '../lib/ngx-bootstrap-product-tour';
import { NgxBootstrapProductTourStepService } from 'lib/ngx-bootstrap-product-tour/ngx-bootstrap-product-tour-step/ngx-bootstrap-product-tour-step.service';
import { AppComponent } from './app.component';

import { AgmCoreModule } from '@agm/core';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { CommonService } from './common/common.service';

@NgModule({
  imports: [
    NgxBootstrapProductTourModule,
    BrowserAnimationsModule,
    NgIdleKeepaliveModule.forRoot(),
    FormsModule,
    HttpModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    PendingInterceptorModule,
    AngularFontAwesomeModule,
    AgmCoreModule.forRoot({
      apiKey: 'YOUR_GOOGLE_MAPS_API_KEY'
    })
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent

  ],
  providers: [CommonService , NgxBootstrapProductTourService, NgxBootstrapProductTourStepService],
  bootstrap: [AppComponent]
})
export class AppModule { }
