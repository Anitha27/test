import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { OttUtility } from './common/OttUtility';
import { AppComponent } from './app.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { Keepalive } from '@ng-idle/keepalive';

import { RouterTestingModule } from '@angular/router/testing';
import { CommonService } from '../app/common/common.service';
import { CommonServiceMock } from './mocks/common-mock.service';
import { Observable, Observer } from 'rxjs';
fdescribe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      providers: [
         CommonService,
        Keepalive
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NgIdleKeepaliveModule
      ]
    }).compileComponents();
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
  }));
  function setup() {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    const commonService = fixture.debugElement.injector.get(
      CommonService
    );
    return { fixture, app, commonService };
  }

  it('should create the app', async(() => {
    const { app } =  setup();
    expect(app).toBeTruthy();
  }));

  it(`should login`, fakeAsync(() => {
    const { fixture, app, commonService } = setup();
    const loggedinResponce = {
      'userId': '3535076',
      'userFirstName': 'Erika',
      'userLastName': 'Lakatos',
      'countryCode': 'NL',
      'userEmail': 'elakatos@fedex.com',
      'authroizes': {
          'CountryLevelTariffHistory,Approve': true,
          'OwnTariffHistory,Approve': false,
          'PricingMD,Allow': false,
          'SalesInput,Write': true,
          'PricingAnalyst,Allow': false,
          'AllTariffHistory,Approve': false,
          'PricingManager,Allow': false,
          'ApplicationLogin,Login': true,
          'PricingEurope,Allow': false,
          'PricingHQ,Allow': false
      }
  }
    spyOn(commonService, 'getHttpLoginResponse').and.returnValue(
      Observable.create((observer: Observer<any>) => {
        observer.next(loggedinResponce);
        return observer;
      })
    );

    tick();
      console.log(OttUtility.userDetails)
    fixture.detectChanges();
    expect(OttUtility.userDetails.userId).toBe('3535076');
  }));

  // it('should render title in a h1 tag', async(() => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.debugElement.nativeElement;
  //   expect(compiled.querySelector('h1').textContent).toContain('app works!');
  // }));
});
