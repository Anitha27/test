import { Component, OnInit } from '@angular/core';
import { NgxBootstrapProductTourService } from '../../lib/ngx-bootstrap-product-tour';

@Component({
  selector: 'app-tour-component',
  templateUrl: './tour-component.component.html',
  styleUrls: ['./tour-component.component.css']
})
export class TourComponentComponent implements OnInit {

  public loaded = false;
  constructor(public tourService: NgxBootstrapProductTourService) {
    this.loaded = false;
    this.tourService.events$.subscribe(console.log);
    this.tourService.initialize([{
      anchorId: 'start.tour',
      content: 'Welcome to the Test App',
      placement: 'right',
      title: 'Welcome',
      orphan: true,
      promise: this.apiSimulation(),
      backdrop: true
    },
    {
      anchorId: 'ngx-tour',
      content: 'give some valid email id Ex:abc@g.com',
      title: 'Email',
      placement: 'bottom',
      backdrop: true
    }, {
      anchorId: 'ngx-pass',
      content: 'Enter valid password',
      title: 'password',
      placement: 'bottom',
      backdrop: true
    }, {
      anchorId: 'ngx-submit',
      content: 'submit',
      title: 'submit',
      placement: 'top',
      backdrop: true
    }], {
        route: '',
        containerClass: 'example-custom-container-class'
      });
  }

  ngOnInit(){
    this.tourService.toggle();
  }

  apiSimulation(): Promise<any> {
    return this.apiDataLoad().then((data) => {
      this.loaded = data;
      return new Promise(function (resolve, reject) {
        setTimeout(() => { resolve(true); });
      });
    });
  }

  apiDataLoad(): Promise<boolean> {
    return new Promise(function (resolve, reject) {
      setTimeout(() => {
        resolve(true);
      }, 1000);
    });
  }

}
