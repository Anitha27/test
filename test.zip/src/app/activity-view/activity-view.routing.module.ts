import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivityViewComponent } from './activity-view.component';

const routes: Routes = [
    { path: 'activity',     component: ActivityViewComponent },
    { path: 'activity/:salesFeedNumber',     component: ActivityViewComponent },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ActivityViewRoutingModule { }
