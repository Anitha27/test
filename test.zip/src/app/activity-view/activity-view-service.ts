import { Injectable } from '@angular/core';
import { CommonService } from '../common/common.service';
import { OttUtility } from '../common/OttUtility';
import { elementEventFullName } from '@angular/compiler/src/view_compiler/view_compiler';

@Injectable()
export class ActivityViewService {

    searchSortConfig = {
        status: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.status = value;
            }
            return filterObj;
        },
        trfTyp: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.trfTypNm = value;
            }
            return filterObj;
        },
        country: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.countryId = value;
            }
            return filterObj;
        },
        tariffNo: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.referenceOrCompanyName = value;
            }
            return filterObj;
        },
    }

    errorMessages = {
        errPastDate: 'The Tariff you try to download is based on an older version of the Tariff Guide template and is not applicable'
            + 'any more.'
            + 'List prices, weight structure, zoning and surcharges have been updated. Please re-create your Tariff using the'
            + 'current settings.',
        noPTdoc: 'No documents have been uploaded for this Personalised tariff.',
        noDoc: 'No tariffs generated/downloaded for this tariff.'
    };

    private filterConfig = {
        status: (value) => {
            if (value === 'All') {
                return null;
            }
            return value;
        },
        referenceOrCompanyName: (value) => {
            if (!value) {
                return null;
            }
            return value;
        },
        trfTypNm: (value) => {
            if (value === 'All') {
                return null;
            }
            return value;
        },
        countryId: (value) => {
            if (!value) {
                return null;
            }
            return value;
        }
    }

    constructor(private commonService: CommonService) {

    }

    generateInitSearch() {
        const reqArr = [];
        // Get Statuses
        const requestStatus = {
            url: (OttUtility.urlParams.businessServiceBaseUrl.url + OttUtility.urlParams.getStatuses.url),
            param: null,
            type: OttUtility.urlParams.getStatuses.type
        }
        reqArr.push(requestStatus);
        // Get Op Unit Details
        const requestOpUnits = {
            url: (OttUtility.urlParams.businessServiceBaseUrl.url + OttUtility.urlParams.getCountryOP.url),
            param: {
                ctryCd: (OttUtility.userDetails && OttUtility.userDetails.countryCode) ?
                    OttUtility.userDetails.countryCode : '',
                customerType: (OttUtility.roleActions && OttUtility.roleActions.roleName) ?
                    OttUtility.roleActions.roleName : '',
                type: 'GET'
            },
            type: OttUtility.urlParams.getCountryOP.type
        }
        reqArr.push(requestOpUnits);
        return reqArr;
    }

    processRequestFilter(filterObj) {
        if (filterObj && filterObj.searchCriteria) {
            // tslint:disable-next-line:forin
            for (const i in filterObj.searchCriteria) {
                filterObj.searchCriteria[i] = this.filterConfig[i](filterObj.searchCriteria[i]);
                if (!filterObj.searchCriteria[i]) {
                    delete filterObj.searchCriteria[i];
                }
            }
        }
        return filterObj;
    }

    resetFilters(filterObj: any) {
        const basicDetails = {
            countryId: (OttUtility.loggedInCountryDetails && OttUtility.loggedInCountryDetails.countryInfo &&
                OttUtility.loggedInCountryDetails.countryInfo.ctryIdNbr) ?
                OttUtility.loggedInCountryDetails.countryInfo.ctryIdNbr : 0,
            ldapIdNbr: (OttUtility.userDetails && OttUtility.userDetails.userId) ?
                OttUtility.userDetails.userId : '0',
            customerType: (OttUtility.roleActions && OttUtility.roleActions.roleName) ?
                OttUtility.roleActions.roleName : ''
        };
        filterObj = {
            countryId: basicDetails.countryId,
            ldapIdNbr: basicDetails.ldapIdNbr,
            customerType: basicDetails.customerType,
            pageNum: 1,
            pageSize: '20',
            searchCriteria: {
                status: 'All',
                referenceOrCompanyName: null,
                trfTypNm: 'All',
                countryId: 0
            },
            sortCriteria: {
                updateDate: '0',
                effectiveDate: null,
                proposalDate: null
            }
        };
        return filterObj;
    }

    setPagination(pageObj, updatedPageObj, updateFilter = false, filterObj = null) {
        if (pageObj && updatedPageObj) {
            pageObj.pageIndex = (updatedPageObj.pageIndex + 1);
            pageObj.pageSize = updatedPageObj.pageSize;

            if (updateFilter && filterObj) {
                filterObj.pageSize = '' + updatedPageObj.pageSize;
                filterObj.pageNum = updatedPageObj.pageIndex + 1;
            }
        }
        return updatedPageObj;
    }

    resetPagination(pageObj: any) {
        if (pageObj) {
            pageObj.length = 0;
            pageObj.pageSize = 20;
            pageObj.pageSizeOptions = [10, 20, 50];
            pageObj.pageIndex = 0;
            pageObj.showFirstLastButtons = true;
        }
        return pageObj;
    }

    getTariffTypeColor(type) {
        const color = 'light';
        const badgeType = {
            'Standard Tariff': 'primary',
            'Personalised Tariff': 'success',
            'Periodic Volume Discount': 'secondary',
            'Fast Track Tariff': 'warning',
            'Band': 'info',
        };
        return (badgeType[type]) ? badgeType[type] : color;
    }

    checkDisabledField(elementType, obj) {
        const elementDecision = {
            'statusDrpdwn': (param = null) => {
                if (OttUtility.roleActions && OttUtility.roleActions.actions
                    && OttUtility.roleActions.actions.indexOf('statusChange') === -1) {
                    return true;
                }
                return false;
            },
            'disableEdit': (param) => {
                if (!param) {
                    return false;
                }
                if (param.status === 'Signed' || param.status === 'Not Awarded'
                    || param.status === 'Solution Design' || param.status === 'Submitted'
                    || param.status === 'Available') {
                    return true;
                }
                return false;
            },
            'showInfo': (element) => {
                if (element.trfTypNm === 'Personalised Tariff') {
                    return true;
                }
                return false;
            },
            'approveRejct': (element) => {
                if (OttUtility.roleActions && OttUtility.roleActions.actions
                    && OttUtility.roleActions.actions.indexOf('approval_pt') > -1
                    && element.trfTypNm === 'Personalised Tariff'
                    && element.status !== 'Solution Design') {
                    return true;
                }
                return false;
            },
            'submitted': (element) => {
                if (OttUtility.roleActions && OttUtility.roleActions.roleUser
                    && OttUtility.roleActions.roleUser === 'SALES'
                    && element.trfTypNm === 'Personalised Tariff'
                    && element.status !== 'Available') {
                    return true;
                }
                return false;
            },
            'implementation': (element) => {
                if (OttUtility.roleActions && OttUtility.roleActions.roleUser === 'RatingAdmin') {
                    if (element.status === 'Pending Implementation') {
                        if (element.trfTypNm === 'Personalised Tariff'
                            || element.trfTypNm === 'Fast Track Tariff') {
                            return true;
                        }
                    }
                    if (element.status === 'Signed') {
                        if (element.trfTypNm !== 'Personalised Tariff'
                            && element.trfTypNm !== 'Fast Track Tariff') {
                            return true;
                        }
                    }
                }
                return false;
            },
            'approve': (element) => {
                if (OttUtility.roleActions && OttUtility.roleActions.roleUser !== 'RatingAdmin'
                    && element.status === 'Submitted') {
                    return true;
                }
                return false;
            },
            'reject': (element) => {
                if (OttUtility.roleActions && OttUtility.roleActions.roleUser !== 'RatingAdmin'
                    && element.status === 'Submitted') {
                    return true;
                }
                return false;
            }
        };
        return (elementDecision[elementType]) ? elementDecision[elementType](obj) : false;
    }

    checkStatusElement(elementType, obj) {
        const elementDecision = {
            'Saved On': (element) => {
                if (element.status === 'Solution Design') {
                    return true;
                }
                return false;
            },
            'Download Tariff': (element) => {
                if (element.trfTypNm === 'Personalised Tariff') {
                    if (OttUtility.roleActions && OttUtility.roleActions.roleUser !== 'SALES'
                        || (OttUtility.roleActions.roleUser === 'SALES' &&
                            element.status === 'Available' || element.status === 'Submitted')) {
                        return true;
                    }
                }
                if (OttUtility.roleActions && OttUtility.roleActions.roleUser !== 'RatingAdmin'
                    && element.status !== 'Solution Design') {
                    return true;
                }
                if (OttUtility.roleActions && OttUtility.roleActions.roleUser === 'RatingAdmin'
                    && element.trfTypNm === 'Fast Track Tariff' && element.status !== 'Solution Design') {
                    return true;
                }
                return false;
            },
            'Download LI': (element) => {
                if (element.trfTypNm === 'Personalised Tariff') {
                    if (OttUtility.roleActions && OttUtility.roleActions.roleUser !== 'RatingAdmin'
                        && OttUtility.roleActions.roleUser !== 'SALES'
                        && (element.status === 'Implemented'
                            || element.status === 'Partly Awarded'
                            || element.status === 'Pending Implementation'
                            || element.status === 'Signed')) {
                        return true;
                    } else if (OttUtility.roleActions
                        && OttUtility.roleActions.roleUser === 'RatingAdmin'
                        && (element.status === 'Pending Implementation'
                            || element.status === 'Implemented')) {
                        return true;
                    }
                }
                if (element.trfTypNm === 'Fast Track Tariff' && OttUtility.roleActions
                    && OttUtility.roleActions.roleUser !== 'SALES' && (element.status === 'Signed'
                        || element.status === 'Implemented'
                        || element.status === 'Pending Implementation')) {
                    return true;
                }
                return false;
            },
            'Upload LI': (element) => {
                if (element.trfTypNm === 'Personalised Tariff'
                    && (element.status === 'Signed' || element.status === 'Partly Awarded')
                    && OttUtility.roleActions.actions
                    && OttUtility.roleActions.actions.indexOf('upload_li') > 0) {
                    return true;
                }
                return false;
            },
        }
        return (elementDecision[elementType]) ? elementDecision[elementType](obj) : false;
    }

    performAction(obj, type, templates) {
        const actions = {
            'DownloadTariff': (element) => {
                const staticCmprDt = new Date('09/03/2018');
                if (new Date(element.savedOn) <= staticCmprDt
                    || new Date(obj.trfCreationDate) <= staticCmprDt) {
                    this.commonService.showNotifier(this.errorMessages.errPastDate, 'error');
                    return;
                }
                if (element.trfTypNm === 'Personalised Tariff') {
                    if (!element.ptfileAvailable) {
                        this.commonService.showNotifier(this.errorMessages.noPTdoc, 'error');
                        return;
                    }
                    let url = OttUtility.urlParams.businessServiceBaseUrl.url;
                    url += `${OttUtility.urlParams.downloadPT.url}${element.reference}/PT?&roleNm=${OttUtility.roleActions.roleUser}`;
                    url += `&usrsLdapIdNbr=${OttUtility.userDetails.userId}
                    &usrsEmalNm=${encodeURIComponent(OttUtility.userDetails.userEmail)}`
                    window.open(url);
                    return;
                }
                if (element.trfTypNm !== 'Fast Track Tariff') {
                    const selectedRates = { I: [], D: [] };
                    if (element.selectedRates && element.selectedRates.length > 0) {
                        let baseUrl = OttUtility.urlParams.businessServiceBaseUrl.url;
                        baseUrl += (element.slsTrfTypNm === 'D') ? OttUtility.urlParams.getBandDownloadTrf.url
                            : OttUtility.urlParams.genStdTariff.url;
                        baseUrl += `?salesFeedNbr=${element.reference}`;
                        element.selectedRates.map((rate) => {
                            const downloadType = (element.slsTrfTypNm === 'D') ? '&typ=download' : `&type=${rate.type}`;
                            const url = (element.slsTrfTypNm === 'D') ? `${baseUrl}&bandCd=${rate.rtngCtgryCd}${downloadType}`
                                : `${baseUrl}&rtCtgyCd=${rate.rtngCtgryCd}${downloadType}`;
                            selectedRates[rate.type].push({ rtCode: rate.rtngCtgryCd, url: url });
                        });
                        return { modal: templates.fileTypeDownload, data: selectedRates }
                    } else {
                        this.commonService.showNotifier(this.errorMessages.noDoc, 'error');
                        return;
                    }
                }
                if (element.trfTypNm === 'Fast Track Tariff') {
                    const languages = [];
                    let defaultLanguage: any = null;
                    if (element.countryLangInfos) {
                        const baseUrl = OttUtility.urlParams.businessServiceBaseUrl.url;
                        const basePdf = OttUtility.urlParams.generatePDF.url;
                        const baseXL = OttUtility.urlParams.generatePDF.url;
                        const roleName = OttUtility.roleActions.roleUser;
                        const userId = OttUtility.userDetails.userId;
                        const userEmail = encodeURIComponent(OttUtility.userDetails.userEmail);
                        element.countryLangInfos.map((country) => {
                            let paramUrl = `?salesFeedNbr=${element.reference}&langIdNbr=${country.ctryLangIdNbr}`;
                            paramUrl += `&roleNm=${roleName}&usrsLdapIdNbr=${userId}&usrsEmalNm=${userEmail}`
                            const pdfUrl = `${baseUrl}${basePdf}${paramUrl}`;
                            const excelUrl = `${baseUrl}${baseXL}${paramUrl}`;
                            const langObj = {
                                langNm: country.langNm, ctryLangIdNbr: country.ctryLangIdNbr,
                                pdfUrl: pdfUrl, excelUrl: excelUrl
                            };
                            if (!defaultLanguage) {
                                defaultLanguage = langObj;
                            }
                            languages.push(langObj);
                        });
                        return { modal: templates.fileTypeDownloadFTT, data: languages};
                    } else {
                        return {};
                    }
                }
            },
            'DownloadLI': (element) => {

            },
            'UploadLI': (element) => {

            },
            'statusDrpdwn': (element) => {

            },
            'showInfo': (element) => {

            },
            'approveRejct': (element) => {

            },
            'submitted': (element) => {

            },
            'implementation': (element) => {

            },
            'approve': (element) => {

            },
            'reject': (element) => {

            }
        };
        return (actions[type]) ? actions[type](obj) : null;
    }
}
