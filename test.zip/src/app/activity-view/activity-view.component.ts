import { Component, OnInit, Input, ViewChild, OnDestroy, ContentChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { ReplaySubject } from 'rxjs/internal/ReplaySubject';
import { filter, debounceTime } from 'rxjs/operators';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

import { CommonService } from '../common/common.service';
import { OttUtility } from '../common/OttUtility';
import { ActivityViewService } from './activity-view-service';

declare interface SortCriteria {
    updateDate: string;
    effectiveDate: string;
    proposalDate: string;
}

declare interface SearchCriteria {
    status: string;
    referenceOrCompanyName: string;
    trfTypNm: string;
    countryId: number;
}

declare interface FilterInfo {
    countryId: number;
    customerType: string;
    ldapIdNbr: string;
    pageNum: number;
    pageSize: string;
    searchCriteria: SearchCriteria;
    sortCriteria: SortCriteria;
}

declare interface Pagination {
    length: number;
    pageSize: number;
    pageSizeOptions: number[];
    pageIndex: number;
    showFirstLastButtons: boolean;
}

@Component({
    selector: 'app-generate-tariff',
    templateUrl: './activity-view.component.html',
    styleUrls: ['./activity-view.component.scss']
})

export class ActivityViewComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;

    @ViewChild('fileTypeDownload')
    fileTypeDownload: ViewContainerRef;

    @ViewChild('fileTypeDownloadFTT')
    fileTypeDownloadFTT: ViewContainerRef;

    filter: FilterInfo;
    tariffStatuses: any = [];
    tariffTypes: any = [];
    opCountries: any = [];
    paginationObj: Pagination;
    tariffs: any = [];
    tariffStatusMap: any = {};
    getTariffTypeColor: any;
    checkStatusElement: any;
    checkDisabledField: any;
    dialogRef: any;
    dialogData: any;

    constructor(private commonService: CommonService, private route: ActivatedRoute,
        private dialog: MatDialog, private activityService: ActivityViewService) {
        this.resetFilters();
        this.paginationObj = this.activityService.resetPagination({});
        this.getTariffTypeColor = this.activityService.getTariffTypeColor;
        this.checkStatusElement = this.activityService.checkStatusElement;
        this.checkDisabledField = this.activityService.checkDisabledField;
    }

    ngOnInit(): void {
        const reqArr = this.activityService.generateInitSearch();
        this.commonService.getGenericForkJoin(reqArr).subscribe(responseList => {
            const statusesResponse = responseList[0];
            const opCountryResponse = responseList[1];
            let statusArr = [];
            this.tariffTypes = [{ tariff: 'All', tariffTypeId: 0 }].concat(statusesResponse);
            this.opCountries = [{ CTRY_NM: 'All', CTRY_ID_NBR: 0 }].concat(opCountryResponse);
            this.tariffTypes.map((tariff) => {
                if (tariff.stsLst) {
                    this.tariffStatusMap[tariff.tariff] = tariff.stsLst.sort((a: any, b: any) => a.salesStatusId - b.salesStatusId);
                    statusArr = tariff.stsLst.filter((i) => { return statusArr.indexOf(i.salesStatusNm) < 0 });
                }
            });
            this.tariffStatuses = [{ salesStatusNm: 'All', salesStatusId: 0 }].concat(statusArr);
            this.filterData();
        }, (error) => {
            console.log('Error');
            console.log(error);
        });
    }

    filterData() {
        const request = this.activityService.processRequestFilter(JSON.parse(JSON.stringify(this.filter)));
        const url = OttUtility.urlParams.businessServiceBaseUrl.url + OttUtility.urlParams.activityVwPgs.url;
        const type = OttUtility.urlParams.activityVwPgs.type;
        this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
            if (response && response.status === 'EXCEPTION') {
                if (response.message) {
                    this.commonService.showNotifier(response.message, 'error');
                } else {
                    this.commonService.showNotifier('Error occurred while getting data.', 'error');
                }
                return;
            }
            this.paginationObj.length = response.totalRecords;
            this.paginationObj.pageIndex = (response.currentPage === 0) ? response.currentPage : (response.currentPage - 1);
            this.paginationObj.pageSize = response.totalRecordsInCrtPage;
            if (response.activityList) {
                this.tariffs = response.activityList;
            }
        });
    }

    resetFilters(filterAfterReset = false) {
        this.filter = this.activityService.resetFilters(filter);
        if (filterAfterReset) {
            this.filterData();
        }
    }

    onFilterChange(value, type) {
        if (value && this.activityService.searchSortConfig[type]) {
            this.filter = this.activityService.searchSortConfig[type](value, this.filter);
        } else {
            this.commonService.showNotifier('No Filter Config found', 'error');
        }
    }

    onPage(value) {
        this.activityService.setPagination(this.paginationObj, value, true, this.filter);
        this.filterData();
    }

    gridChangeFormat(date) {
        return this.commonService.formatDateTime(new Date(date), 'DD/MM/YYYY');
    }

    performAction(element, type) {
        const templates = {
            fileTypeDownload: this.fileTypeDownload,
            fileTypeDownloadFTT: this.fileTypeDownloadFTT
        }
        const response = this.activityService.performAction(element, type, templates);
        if (response && response.modal) {
            this.openModal(response.modal, response.data);
        }
    }

    openModal(templateRef, data = null) {
        this.dialogData = data;
        this.dialogRef = this.dialog.open(templateRef, {});
        this.dialogRef.afterClosed().subscribe(result => {
            this.dialogData = null;
        });
    }

    closeModal() {
        this.dialogRef.close(null);
    }
}
