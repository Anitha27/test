import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivityViewRoutingModule } from './activity-view.routing.module';
import { ActivityViewComponent } from './activity-view.component';
import { ActivityViewService } from './activity-view-service';
import { MaterialModule } from '../material.module';
import { ComponentsModule } from 'app/components/components.module';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ActivityViewRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        MaterialModule,
        ComponentsModule
    ],
    providers: [ActivityViewService],
    declarations: [ActivityViewComponent],
    exports: [ActivityViewComponent],
})
export class ActivityViewModule { }
