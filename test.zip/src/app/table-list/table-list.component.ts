import { Component, OnInit, Input, ViewChild, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { ReplaySubject } from 'rxjs/internal/ReplaySubject';
import { filter } from 'rxjs/operators';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

import { CommonService } from '../common/common.service';
import { OttUtility } from '../common/OttUtility';
import { ListColumn } from 'app/components/list/list-column.model';

// TODO: THIS needs to be removed.

import * as TTConfig from '../components/dynamic-filter/static-data/TT-screens-config.json';
import * as STConfig from '../components/dynamic-filter/static-data/ST-screens-config.json';
import * as PTConfig from '../components/dynamic-filter/static-data/PT-screens-config.json';
import { Subscription } from 'rxjs';
import { TableListDetailComponent } from './table-list-detail/table-list-detail.component';

declare var $: any;
@Component({
  selector: 'app-table-list',
  templateUrl: './table-list.component.html',
  styleUrls: ['./table-list.component.css']
})
export class TableListComponent implements OnInit, OnDestroy {

  subject$: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  data$: Observable<any[]> = this.subject$.asObservable();
  users: any[];
  roles: string[];
  filter: any = {};
  component: any;
  tempData: any;
  title;
  subTitle;
  formData: FormData = new FormData();
  @Input()
  columns: ListColumn[] = [] as ListColumn[];

  profileConfigName: any = '';
  pageSize = 10;
  dataSource: MatTableDataSource<File> | null;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  columnsTemplate: any = [
    { name: 'Checkbox', property: 'checkbox', visible: false },
    { name: 'Actions', property: 'actions', visibleType: 'both', visible: true },
  ]

  resultSubscription: Subscription;
  dynamicEvents: any = {};

  screenConfig: any = {};
  previousRow: any;
  rowsToUpdate: any;
  currentRow: any;
  blockBulkUpdate: boolean;

  initConfig = null;

  constructor(private commonService: CommonService, private route: ActivatedRoute, private dialog: MatDialog) {
    let scrnConfig: any;
    this.component = this;
    this.route.params.subscribe(params => {

      this.clearData();
      if (params.profileConfig) {
        this.profileConfigName = params.profileConfig;
        this.columns = JSON.parse(JSON.stringify(this.columnsTemplate));
        if (this.profileConfigName === 'TTS') {
          scrnConfig = TTConfig;
          delete scrnConfig.default;
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'PTS') {
          scrnConfig = PTConfig;
          delete scrnConfig.default;
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);

        } else if (this.profileConfigName === 'STS') {
          scrnConfig = STConfig;
          delete scrnConfig.default;
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        }
      }
      this.title = scrnConfig.title;
      this.subTitle = scrnConfig.subTitle;
      this.populateDynamicEvents();
    });
  }

  populateDynamicEvents() {
    if (this.screenConfig.eventConfig) {
      try {
        for (const i in this.screenConfig.eventConfig) {
          if (this.screenConfig.eventConfig[i]) {
            this.dynamicEvents[i] = new Function('payload', this.screenConfig.eventConfig[i]);
          }
        }
      } catch (e) {
        console.log(e);
      }
    }
  }

  processTableHeaders(configObj) {
    if (configObj.table && configObj.table.length > 0) {
      let count = 1;
      const cols = this.columns;
      configObj.table.map((colConfig) => {
        cols.splice(count, 0, colConfig);
        count += 1;
      });
    }
  }

  ngOnInit() {
    this.resultSubscription = this.commonService.getFilteredResults()
      .subscribe((data) => {
        const payload = { component: this.component, getResponse: data, utility: OttUtility };
        if (this.dynamicEvents.get) {
          data = this.dynamicEvents.get(payload);
        }
        this.subject$.next(data);

        this.dataSource = new MatTableDataSource();

        this.data$.pipe(
          filter(Boolean)
        ).subscribe((users) => {
          this.users = users;
          this.dataSource.data = users;
        });

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        const defaultPredicate = this.dataSource.filterPredicate;
        this.dataSource.filterPredicate = (dataFilter, filterPredicate) => {
          const formatted = this.gridChangeFormat(dataFilter['EFF_DT']);
          return formatted.indexOf(filterPredicate) >= 0 || defaultPredicate(dataFilter, filterPredicate);
        }
      });
  }

  clearData() {
    this.subject$.next([]);

    this.dataSource = new MatTableDataSource();

    this.data$.pipe(
      filter(Boolean)
    ).subscribe((users) => {
      this.users = users;
      this.dataSource.data = users;
    });

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  getConfig() {
    // TODO: Need to complete the config part.
  }

  // TODO: THis is a temp function delete this
  deleteDefaults(data) {
    const result = [];
    for (const i in data) {
      if (i !== 'default' && data[i]) {
        result.push(data[i]);
      }
    }
    return result;
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  onFilterChange(value) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  createRow() {
    if (!this.screenConfig.createUpdateForm) {
      this.commonService.showNotifier('No Crud Operations Configured', 'error');
      return;
    }
    TableListDetailComponent.configuration = this.screenConfig.createUpdateForm;
    TableListDetailComponent.existingData = null;
    const ref = this.dialog.open(TableListDetailComponent);
    const sub = ref.componentInstance.onSubmit.subscribe((data) => {
      if (!data) {
        return;
      }
      let request = [];
      const payload = { component: this.component, createData: data, utility: OttUtility };
      if (this.dynamicEvents.add) {
        request = this.dynamicEvents.add(payload);
      } else {
        request = this.rowsToUpdate;
      }
      if (this.screenConfig.ajaxUrls.add) {
        const url = OttUtility.urlParams.adminServiceBaseUrl.url +
          OttUtility.urlParams[this.screenConfig.ajaxUrls.add].url;
        const type = OttUtility.urlParams[this.screenConfig.ajaxUrls.add].type;
        this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
          if (response && response.status === 'EXCEPTION') {
            this.commonService.showNotifier('An error occurred while adding data.', 'error');
            return;
          }
          if (response) {
            this.commonService.showNotifier('Row Added Successfully.', 'success');
            ref.close();
            $('.goBtn').trigger('click')
          }
        }, (error) => {
          console.log(error);
          this.commonService.showNotifier('An error occurred while adding data.', 'error');
        });
      } else {
        this.commonService.showNotifier('No Save Operations Configured', 'error');
        return;
      }
    });
    ref.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  deleteRow(row) {
    let request = row;
    const payload = { component: this.component, deleteData: row, utility: OttUtility };
    if (this.dynamicEvents.delete) {
      request = this.dynamicEvents.delete(payload);
    }
    if (this.screenConfig.ajaxUrls.delete) {
      const url = OttUtility.urlParams.adminServiceBaseUrl.url +
        OttUtility.urlParams[this.screenConfig.ajaxUrls.delete].url;
      const type = OttUtility.urlParams[this.screenConfig.ajaxUrls.delete].type;
      this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
        if (response && response.status === 'EXCEPTION') {
          this.commonService.showNotifier('An error occurred while updating data.', 'error');
          return;
        }
        if (response) {
          this.commonService.showNotifier('Row Deleted Successfully.', 'success');
          $('.goBtn').trigger('click');
        }
      }, (error) => {
        console.log(error);
      });
    } else {
      this.commonService.showNotifier('No Delete Operations Configured', 'error');
      return;
    }
  }

  updateRow(row) {
    // Intentionally Commented
    // if (!row && this.previousRow) {
    //   this.previousRow.isEditing = false;
    //   this.previousRow = null;
    //   return;
    // } else if (!row && !this.previousRow) {
    //   return;
    // }

    if (!this.screenConfig.createUpdateForm) {
      this.commonService.showNotifier('No Crud Operations Configured', 'error');
      return;
    }
    if (this.previousRow) {
      this.previousRow.isEditing = false;
    }
    row.isEditing = true;
    row.isEdited = false;
    this.previousRow = row;
    this.tempData = JSON.parse(JSON.stringify(row));
  }

  gridChangeFormat(date) {
    return this.commonService.formatDateTime(new Date(date), 'DD/MM/YYYY');
  }

  saveUpdateRow(row) {
    if (!this.rowsToUpdate) {
      this.rowsToUpdate = [];
    }

    if (JSON.stringify(this.tempData) !== JSON.stringify(row)) {
      const temRow = JSON.parse(JSON.stringify(row));
      delete temRow['isEditing'];
      delete temRow['isEdited'];
      this.rowsToUpdate.push(temRow);
      row.isEdited = true;
    } else {
      row.isEdited = false;
    }
    row.isEditing = false;
    if (this.screenConfig.isInlineEdit) {
      this.rowsToUpdate = [row];
      this.currentRow = row;
      this.update(true);
    }
  }

  fileSelected(row: any, files: any) {
    row.files = files[0];
  }

  update(isPartial = false) {
    if (this.blockBulkUpdate && !isPartial) {
      $('.goBtn').trigger('click');
    }
    if (this.rowsToUpdate && this.rowsToUpdate.length > 0) {
      let request;
      const payload = { component: this.component, updateArr: this.rowsToUpdate, utility: OttUtility };
      if (this.dynamicEvents.update) {
        request = this.dynamicEvents.update(payload);
      } else {
        request = this.rowsToUpdate;
      }

      if (this.screenConfig.ajaxUrls.add) {
        const url = OttUtility.urlParams.adminServiceBaseUrl.url +
          OttUtility.urlParams[this.screenConfig.ajaxUrls.add].url;
        const type = OttUtility.urlParams[this.screenConfig.ajaxUrls.add].type;
        this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
          if (response && response.status === 'EXCEPTION') {
            if (isPartial) { // TODO: Row level Validation
              this.blockBulkUpdate = true;
            } else {
              this.blockBulkUpdate = false;
            }
            if (response.message) {
              this.commonService.showNotifier(response.message, 'error');
            } else {
              this.commonService.showNotifier('An error occurred while updating data.', 'error');
            }
            return;
          }
          if (response) {
            this.rowsToUpdate = [];
            if (!isPartial) {
              this.commonService.showNotifier('Rows Updated Successfully.', 'success');
              $('.goBtn').trigger('click');
            } else {
              // Intentionally Commented
              // this.commonService.showNotifier('Record Updated.', 'success');
            }
          }

        }, (error) => {
          console.log(error);
          if (!isPartial) {
            this.commonService.showNotifier('An error occurred while updating data.', 'error');
          }
        });
      } else {
        this.commonService.showNotifier('No Save Operations Configured', 'error');
        return;
      }

    } else if (this.screenConfig.isInlineEdit) {
      this.commonService.showNotifier('Rows Updated Successfully.', 'success');
      $('.goBtn').trigger('click');
    }
  }
  getColumnProperty(paramName) {
    return OttUtility.commonStaticObject[paramName];
  }

  ngOnDestroy(): void {
    this.resultSubscription.unsubscribe();
  }
}
