import { Component, OnInit, Input, ViewChild, Inject, Output, EventEmitter } from '@angular/core';

import { FormBuilder, FormGroup, FormControl, Validator, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { MatAutocompleteSelectedEvent, MatChipInputEvent } from '@angular/material';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Observable, ReplaySubject } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatChipsModule } from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { OttUtility } from '../../common/OttUtility';
import { CommonService } from '../../common/common.service';
import { DynamicFormComponent } from '../../components/dyn-forms/dynamic-form/dynamic-form.component';
import { FieldConfig } from '../../components/dyn-forms/field.interface';

@Component({
    selector: 'app-table-list-detail',
    templateUrl: './table-list-detail.component.html',
    styleUrls: ['./table-list-detail.component.scss'],
    providers: []
})
export class TableListDetailComponent implements OnInit {
    static id = 0;
    static modalType = '';
    static configuration: any;
    static existingData: any;

    mode: any = 'create';
    config: any;
    data: any;

    @Output() onSubmit = new EventEmitter<any>();
    @ViewChild(DynamicFormComponent) form: DynamicFormComponent;
    fieldConfigMap: any = {};
    currentFormTitle = '';
    regConfig: FieldConfig[] = [];

    constructor(@Inject(MAT_DIALOG_DATA) public defaults: any,
        private dialogRef: MatDialogRef<TableListDetailComponent>,
        private fb: FormBuilder, private commonService: CommonService) {
    }

    ngOnInit() {
        this.mode = TableListDetailComponent.modalType;
        this.config = { form: [TableListDetailComponent.configuration] };
        this.data = TableListDetailComponent.existingData;
        this.buildField();
        this.initializeFormView(TableListDetailComponent.configuration.form_name);
    }

    initializeFormView(form_name) {
        if (this.fieldConfigMap[form_name]) {
            const form = this.fieldConfigMap[form_name];
            this.currentFormTitle = form.title;
            this.regConfig = form.fieldsConfig;
        }
    }

    buildField(frmCnfg = null) {
        if (this.config) {
            const configs: any = JSON.parse(JSON.stringify(this.config));
            if (configs.form) {
                const form = configs.form;
                this.fieldConfigMap = {};
                form.map((config) => {
                    // let formConfig: FormConfig;
                    const formConfigObj: any = {};
                    formConfigObj.title = config.name;
                    formConfigObj.form_name = config.form_name;
                    formConfigObj.entity = config.entity;
                    formConfigObj.submitUrl = config.submitUrl;
                    const fieldConfigs: FieldConfig[] = [];

                    if (config.fields) {
                        config.fields.map((field) => {
                            let elementConfig: FieldConfig;
                            const elementObj: any = {};
                            elementObj.inputType = field.inputType;
                            elementObj.type = field.type;
                            elementObj.label = field.label;
                            elementObj.name = field.name;
                            elementObj.styleClass = field.styleClass;
                            elementObj.styleColor = field.styleColor;
                            if (field.value) {
                                elementObj.value = field.value;
                            }
                            if (field.options) {
                                elementObj.options = field.options;
                            }
                            if (field.utilFieldNm) {
                                if (field.type === 'select') {
                                    elementObj.options = OttUtility.commonStaticObject[field.utilFieldNm];
                                }
                                if (field.defaultValueRef) {
                                    elementObj.value = OttUtility.commonStaticObject[field.defaultValueRef];
                                }
                            }
                            if (field.validations) {
                                let validator: Validator[];
                                const validatorArr = [];
                                field.validations.map((validation) => {
                                    const validatorObj: any = {};
                                    if (validation.name === 'required') {
                                        validatorObj.name = validation.name;
                                        validatorObj.validator = Validators.required;
                                        validatorObj.message = validation.message;
                                    } else if (validation.name === 'pattern') {
                                        validatorObj.name = validation.name;
                                        validatorObj.validator = Validators.pattern(validation.validator);
                                        validatorObj.message = validation.message;
                                    }

                                    validatorArr.push(validatorObj);
                                });
                                validator = validatorArr;
                                elementObj.validations = validator;
                            }
                            elementConfig = elementObj;
                            fieldConfigs.push(elementConfig);
                        });
                    }
                    formConfigObj.fieldsConfig = fieldConfigs;
                    this.fieldConfigMap[formConfigObj.form_name] = formConfigObj;
                });
            }
        }
    }

    submit(value: any) {
        this.onSubmit.emit(value);
    }

    closeModal() {
        this.dialogRef.close(null);
    }

    save() {
        if (this.mode === 'create') {
            this.createCustomer();
        } else if (this.mode === 'update') {
            this.updateCustomer();
        }
    }


    createCustomer() {
        const customer = this.form.value;
        this.dialogRef.close(customer);
    }

    updateCustomer() {
        const customer = this.form.value;
        customer.id = this.defaults.id;
        this.dialogRef.close(customer);
    }

    cancelModal() {
        this.dialogRef.close(null);
    }

    isCreateMode() {
        return this.mode === 'create';
    }

    isUpdateMode() {
        return this.mode === 'update';
    }
}
