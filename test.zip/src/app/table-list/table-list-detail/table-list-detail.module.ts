import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../material.module';

import { TableListDetailComponent } from './table-list-detail.component';
import { DynFormModule } from '../../components/dyn-forms/dyn-forms.module';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    DynFormModule
  ],
  declarations: [TableListDetailComponent],
  entryComponents: [TableListDetailComponent],
  providers: [],
  exports: [TableListDetailComponent]
})
export class TableListDetailModule { }
