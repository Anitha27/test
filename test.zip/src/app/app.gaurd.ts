import { Injectable } from '@angular/core';
import { CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { OttUtility } from './common/OttUtility';
@Injectable({
    providedIn: 'root',
})
export class AuthGuard implements CanActivateChild {
    constructor(private router: Router) { }
    canActivateChild(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): boolean {
        const url: string = state.url;
        return this.checkLogin(url);
    }
    checkLogin(url) {
        if (Object.keys(OttUtility.userDetails).length !== 0 && OttUtility.userDetails.constructor === Object
        && Object.keys(OttUtility.loggedInCountryDetails).length !== 0 && OttUtility.loggedInCountryDetails.constructor === Object) {
            return true;
        } else {
            OttUtility.redirection = url;
            return false;
        }
    }
}
