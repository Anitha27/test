import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { MatDialog } from '@angular/material';

import { CommonService } from '../common/common.service';
import { OttUtility } from '../common/OttUtility';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';

import * as screenConfig from './generate-tariff-screenConfig.json';
import { initDomAdapter } from '@angular/platform-browser/src/browser';
@Component({
    selector: 'app-generate-tariff',
    templateUrl: './generate-tariff.component.html',
    styleUrls: ['./generate-tariff.component.scss']
})

export class GenerateTariffComponent implements OnInit {
    isLinear = true;
    formGroups: FormArray;
    screenConfig: typeof screenConfig;
    steppers: Array<any>;
    form: FormGroup;
    commonStaticObject: any = {};
    stepperCount: number;
    constructor(
        private commonService: CommonService,
        private route: ActivatedRoute,
        private dialog: MatDialog,
        private formBuilder: FormBuilder) {
        this.commonStaticObject['salesTerritorys'] = OttUtility.loggedInCountryDetails['salesTerritorys'];
        this.commonStaticObject['tariffTypes'] = OttUtility.loggedInCountryDetails['tariffTypes'];
        this.commonStaticObject['ctryCdNm'] = OttUtility.loggedInCountryDetails['countryInfo'].ctryCdNm;
        this.commonStaticObject['userDetails'] = OttUtility.userDetails;
        this.commonStaticObject['tntContactName'] = `${OttUtility.userDetails.userFirstName} ${OttUtility.userDetails.userLastName}`;
        this.commonStaticObject['countryInfo'] = OttUtility.loggedInCountryDetails['countryInfo'];
        this.commonStaticObject['ctryLangIdNbr'] = this.commonStaticObject.countryInfo['countryLangInfos']
            .filter((ele) => ele.defaultLang === true)[0]['ctryLangIdNbr'];
    }

    ngOnInit() {
        this.screenConfig = JSON.parse(JSON.stringify(screenConfig));
        this.steppers = this.screenConfig['steppers'];
        this.stepperCount = this.steppers.length - 1;
        this.form = this.formBuilder.group({
            formGroups: this.formBuilder.array([])
        });
        this.steppers.forEach((step, ind) => {
            if (step.type === 'form') {
                this.formGroups = this.form.get('formGroups') as FormArray;
                this.formGroups.push(this.createFromGroup(step.fields));
                if (step.events) {
                    if (step.events.onChange) {
                        const event = step.events['onChange'];
                        if (!event.of) {
                            this.form.get('formGroups').get(`${ind}`).valueChanges.subscribe((val) => {
                                if (!this.commonStaticObject.onTotalNetRevenueChange) {
                                    this.executeFunction(event, val);
                                } else {
                                    this.commonStaticObject.onTotalNetRevenueChange = false;
                                }
                            });
                        } else {
                            this.form.get('formGroups').get(`${ind}`).get(event.of).valueChanges.subscribe((val) => {
                                this.executeFunction(event, val)
                            });
                        }
                        if (event.except) {
                            this.form.get('formGroups').get(`${ind}`).get(event.except).valueChanges.subscribe((val) => {
                                this.commonStaticObject.onTotalNetRevenueChange = true;
                            })
                        }
                    }
                }
            }
        });
        this.onNext(-1, this.form.get('formGroups').get('0')); // To initialise events and services in first form
        console.log(this.steppers);
    }
    callService(service) {
        if (service && service.url) {
            const url = `${OttUtility.urlParams.businessServiceBaseUrl.url}${OttUtility.urlParams[service.url].url}`;
            const type = OttUtility.urlParams[service.url].type;
            let request;
            if (service.dynamicParam) {
                request = this.makeJSON(service.dynamicParam);
                console.log(request);
            }
            this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
                if (response && response.status === 'EXCEPTION') {
                    this.commonService.showNotifier('An error occurred', 'error');
                    return;
                }
                if (response) {
                    this.commonService.showNotifier('Successfull.', 'success');
                    this.setProperty(service.responce, response);
                }
            }, (error) => {
                console.log(error);
                this.commonService.showNotifier('An error occurred please try again', 'error');
            });
        }
    }
    makeJSON(dynamicParam) {
        let request;
        if (dynamicParam instanceof Array) {
            request = [];
        } else if (dynamicParam instanceof Object) {
            request = {};
        }
        for (const i in dynamicParam) {
            if (i) {
                if (typeof dynamicParam[i] !== 'object') {
                    let temp = this.getProperty(dynamicParam[i])
                    if (!temp && temp !== 0 && temp !== '') {
                        temp = this.getfieldProperty('countryInfo', dynamicParam[i]) ||
                            this.getfieldProperty('userDetails', dynamicParam[i]) || dynamicParam[i];
                    }
                    request[i] = temp;
                } else if (typeof dynamicParam[i] === 'object') {
                    request[i] = this.makeJSON(dynamicParam[i]);
                }
                if (!dynamicParam[i]) {
                    // Might Change
                    if (i.includes('Dt')) {
                        request[i] = this.commonService.formatDateTime(new Date(), 'YYYY-MM-DDThh:mm:ss' + 'Z');
                    } else {
                        request[i] = dynamicParam[i];
                    }
                } else if (i.includes('Dt')) {
                    request[i] = this.commonService.formatDateTime(new Date(request[i]), 'YYYY-MM-DDThh:mm:ss' + 'Z');
                }
            }
        }
        return request;
    }
    createFromGroup(fields): FormGroup {
        const obj: any = {};
        fields.forEach((field) => {
            const valids = [];
            const obj2: any = { value: '' }
            if (field.validators) {
                field.validators.forEach((dator) => {
                    try {
                        if (!dator.type) {
                            const test = dator.value ? Validators[dator.name](dator.value) : Validators[dator.name];
                            valids.push(test);
                        } else if (dator.type === 'action') {
                            obj2[dator.name] = dator.value;
                        }
                    } catch (e) {
                        console.log(e);
                    }
                });
            }
            obj[field.name] = [Object.keys(obj2).length > 1 ? obj2 : '', Validators.compose(valids)];
            if (field.disable) {
                const utilField = this.getfieldProperty(field.utilFieldNm);
                if (utilField.length) {
                    for (let i = 0; i < utilField.length; i++) {
                        this.setfieldProperty(field.name + 'disable', false, i);
                    }
                } else {
                    this.setfieldProperty(field.name + 'disable', false);
                }
            }
        });
        return this.formBuilder.group(obj);
    }
    getFormValidators(formName, fieldName, validatorName) {
        const formGroup = this.form && this.form.get('formGroups')
        if (formGroup) {
            const form = this.form.get('formGroups').get(`${formName}`)
            if (form && form.get(fieldName)) {
                return form.get(fieldName).touched && form.get(fieldName).hasError(validatorName);
            }
        }
    }
    requiredOrNot(validators) {
        return validators.map(ele => ele.name === 'required').includes(true);
    }
    getfieldProperty(utilFieldNm, on = null) {
        if (utilFieldNm && this.commonStaticObject[utilFieldNm]) {
            if (on !== null) {
                return this.commonStaticObject[utilFieldNm][on];
            }
            return this.commonStaticObject[utilFieldNm];
        }
    }
    getFormfieldProperty(fieldName) {
        if (fieldName) {
            let field;
            for (let i = 0; i < this.steppers.length; i++) {
                if (this.form.get('formGroups').get(`${i}`)) {
                    field = this.form.get('formGroups').get(`${i}`).get(`${fieldName}`) || '';
                }
                if (field) {
                    break;
                }
            }
            return field.value;
        }
    }
    setFormfieldProperty(fieldName, value) {
        let field;
        for (let i = 0; i < this.steppers.length; i++) {
            field = this.form.get('formGroups').get(`${i}`).get(`${fieldName}`) || '';
            if (field) {
                break;
            }
        }
        if (field) {
            field.setValue(value);
            return true;
        }
        return false;
    }
    getProperty(name) {
        if (name) {
            return this.getfieldProperty(name) || this.getFormfieldProperty(name);
        }
        return name;
    }
    executeFunction(funObj, param = undefined) {
        let result;
        if (funObj) {
            if (!param) {
                param = this.getProperty(funObj.param);
                if (funObj.params) {
                    param = {};
                    funObj.params.forEach(ele => {
                        param[ele] = this.getProperty(ele);
                    });
                }
            }
            const func = funObj.func;
            console.log('exe');
            result = (new Function(funObj.param || 'param', func))(param);
            console.log(result);
            if (funObj.ResultfieldName) {
                this.setProperty(funObj.ResultfieldName, result);
            } else {
                return result;
            }
        }
    }
    setProperty(fieldName, value, on = null) {
        if (value && !this.setFormfieldProperty(fieldName, value)) {
            this.setfieldProperty(fieldName, value);
        } else if (value === 0 && !this.setFormfieldProperty(fieldName, value)) {
            this.setfieldProperty(fieldName, value);
        }
    }
    setfieldProperty(fieldName, value, on = null) {
        if (fieldName) {
            if (on !== null) {
                if (this.commonStaticObject[fieldName] && this.commonStaticObject[fieldName].length) {
                    this.commonStaticObject[fieldName][on] = value;
                } else {
                    this.commonStaticObject[fieldName] = [];
                    this.commonStaticObject[fieldName][on] = value;
                }
            } else {
                this.commonStaticObject[fieldName] = value || '';
            }
        }
    }
    onNext(formName, valfroExe = undefined) {
        const nextFrom = formName + 1;
        if (formName > 0) {
            if (this.steppers[formName] && this.steppers[formName].ajaxUrls) {
                const currentService = this.steppers[formName].ajaxUrls['final'];
                this.callService(currentService);
            }
        }
        if (this.steppers[nextFrom]) {
            if (this.steppers[nextFrom].ajaxUrls) {
                const nextService = this.steppers[nextFrom].ajaxUrls['init']
                this.callService(nextService);
            }
            if (this.steppers[nextFrom].events) {
                const event = this.steppers[nextFrom].events['init']
                this.executeFunction(event, valfroExe);
            }
        }
    }
}
