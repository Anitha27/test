import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GenerateTariffComponent } from './generate-tariff.component';

const routes: Routes = [
    { path: 'generate',     component: GenerateTariffComponent },
    { path: 'generate/:salesFeedNumber',     component: GenerateTariffComponent },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GenerateTariffRoutingModule { }
