import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GenerateTariffRoutingModule } from './generate-tariff-routing.module';
import { GenerateTariffComponent } from './generate-tariff.component';
import { MaterialModule } from '../material.module';
import { ComponentsModule } from 'app/components/components.module';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        GenerateTariffRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        MaterialModule,
        ComponentsModule
    ],
    providers: [],
    declarations: [GenerateTariffComponent],
    exports: [GenerateTariffComponent],
})
export class GenerateTariffModule { }
