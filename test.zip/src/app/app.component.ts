import { Component } from '@angular/core';
import { CommonService } from '../app/common/common.service';
import { OttUtility } from './common/OttUtility';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  activate: Boolean = true;
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  roles = ['dashboard'];
  actions = [];
  roleName = '';
  roleUser = '';
  roleLiterals = {
    'AllTariffHistory,Approve': ((value) => {
      if (value) {
        this.roles.push('activity');
        this.roleUser = 'PRICING';
        this.roleName = 'Pricing User';
        this.actions = this.actions.concat(['allTariff', 'edit', 'statusChange', 'approval', 'approval_pt', 'pt_info']);
      }
    }),
    'ApplicationLogin,Login': ((value) => {
      if (!value) {
        this.activate = false;
      }
    }),
    'CountryLevelTariffHistory,Approve': ((value) => {
      if (value) {
        this.roles.push('generate');
        this.roles.push('activity');
        this.roleUser = 'PRICING';
        this.roleName = 'Pricing User';
        this.actions = this.actions.concat(['edit', 'statusChange', 'approval', 'pt_info', 'upload_li']);
      }
    }),
    'OwnTariffHistory,Approve': ((value) => {
      if (value) {
        this.roles.push('generate');
        this.roles.push('activity');
        this.roleUser = 'SALES';
        this.roleName = 'Sales User';
        this.actions = this.actions.concat(['self', 'edit', 'approval', 'pt_info']);
      }
    }),
    'PricingAnalyst,Allow': ((value) => {
      if (value) {
        this.roles.push('generate');
        this.roles.push('activity');
        this.roleUser = 'PricingAnalyst';
        this.roleName = 'Pricing Analyst';
        this.actions = this.actions.concat(['edit', 'statusChange', 'approval', 'pt_info']);
      }
    }),
    'PricingEurope,Allow': ((value) => {
      if (value) {
        this.roles.push('generate');
        this.roles.push('activity');
        this.roleUser = 'PricingEurope';
        this.roleName = 'FTT_Pricing_Europe';
        this.actions = this.actions.concat(['allTariff', 'edit', 'statusChange', 'approval', 'approval_pt', 'pt_info']);
      }
    }),
    'PricingHQ,Allow': ((value) => {
      if (value) {
        this.roles.push('activity');
        this.roles.push('admin');
        this.roleUser = 'PricingHQ';
        this.roleName = 'Pricing HQ';
        this.actions = this.actions.concat(['allTariff', 'edit', 'statusChange', 'approval', 'approval_pt', 'pt_info']);
      }
    }),
    'PricingMD,Allow': ((value) => {
      if (value) {
        this.roles.push('generate');
        this.roles.push('activity');
        this.roleUser = 'PricingMD';
        this.roleName = 'Pricing MD';
        this.actions = this.actions.concat(['allTariff', 'edit', 'statusChange', 'approval', 'approval_pt', 'pt_info']);
      }
    }),
    'PricingManager,Allow': ((value) => {
      if (value) {
        this.roles.push('generate');
        this.roles.push('activity');
        this.roleUser = 'PricingManager';
        this.roleName = 'Pricing Manager';
        this.actions = this.actions.concat(['allTariff', 'edit', 'statusChange', 'approval', 'approval_pt', 'pt_info']);
      }
    }),
    'SalesInput,Write': ((value) => {
      if (!value) {
        this.roles.push('activity');
        this.roleUser = 'RatingAdmin';
        this.roleName = 'Rating Admin';
        this.actions = this.actions.concat(['allTariff', 'edit', 'statusChange', 'approval', 'pt_info']);
      }
    })
  };

  constructor(private commonService: CommonService, private idle: Idle, private keepalive: Keepalive, private router: Router) {
    this.getLoginDetails();
    // sets an idle timeout of 1800 seconds (30min)
    idle.setIdle(1800);
    // sets a timeout period of 5 seconds. after 1805 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onIdleEnd.subscribe(() => this.idleState = 'No longer idle.');
    idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.commonService.logoutOTT();
    });
    idle.onIdleStart.subscribe(() => this.idleState = 'You\'ve gone idle!');
    idle.onTimeoutWarning.subscribe((countdown) => console.log('You will time out in ' + countdown + ' seconds!'));
    // sets the ping interval to 15 seconds
    keepalive.interval(15);
    keepalive.onPing.subscribe(() => this.lastPing = new Date());
    this.reset();
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  getLoginDetails() {
    const url = OttUtility.urlParams.userServiceBaseUrl.url + OttUtility.urlParams.wssoLoginHdr.url;
    this.commonService.getHttpLoginResponse(url).subscribe((response: any) => {
      if (response) {
        OttUtility.userDetails = response;
        if (response && response.authroizes && Object.keys(response.authroizes).length > 0) {
          // tslint:disable-next-line:forin
          for (const i in response.authroizes) {
            this.roleLiterals[i](response.authroizes[i]);
          }
          this.roles = Array.from(new Set(this.roles.map((item: any) => item)));
          this.actions = Array.from(new Set(this.actions.map((item: any) => item)));
          OttUtility.roleActions = {
            roles: this.roles,
            actions: this.actions,
            roleUser: this.roleUser,
            roleName: this.roleName
          };
        } else {
          this.activate = false;
        }
        OttUtility.seSessionStorageItem('userDetails', JSON.stringify(response));
        this.getCountryDetails();
      }
    },
      (error) => {
        console.log(error);
        this.activate = false;
      });
  }

  getCountryDetails() {
    let url = OttUtility.urlParams.businessServiceBaseUrl.url + OttUtility.urlParams.genericInfoUrl.url;
    url += OttUtility.userDetails.countryCode;
    this.commonService.getAPIResponse(url, null, OttUtility.urlParams.genericInfoUrl.type).subscribe((response: any) => {
      if (response && response.status === 'EXCEPTION') {
        console.log(response.message);
        this.activate = false;
        return;
      }
      if (response) {
        OttUtility.loggedInCountryDetails = response;
        if (OttUtility.redirection) {
          this.router.navigate([OttUtility.redirection]);
          OttUtility.redirection = '';
        }
      }
    },
      (error) => {
        console.log(error);
        this.activate = false;
      });
  }
}
